import React, { useState } from "react";

const ToggleMessage = () => {
  const [showMessage, setShowMessage] = useState(false);

  const handleToggle = () => {
    setShowMessage(!showMessage);
  };

  return (
    <div style={styles.container}>
      <button style={styles.button} onClick={handleToggle}>
        Toggle Message
      </button>
      {showMessage && <p style={styles.message}>Hello, welcome to React!</p>}
    </div>
  );
};

// Inline styles for the component
const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "20px",
  },
  button: {
    backgroundColor: "#007bff",
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
    fontWeight: "bold",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    transition: "background-color 1s ease",
  },
  message: {
    marginTop: "15px",
    fontSize: "18px",
    color: "#333",
  },
};

export default ToggleMessage;

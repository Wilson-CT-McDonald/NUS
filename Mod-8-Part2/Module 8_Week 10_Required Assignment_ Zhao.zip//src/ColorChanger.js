import React, { useState } from "react";

const ColorChanger = () => {
  // To hold user input color
  const [color, setColor] = useState("");

  // Function to validate color input
  // return true when the input color is valid, else false
  const isValidColor = (color) => {
    const s = new Option().style;
    s.color = color;
    return s.color !== "";
  };

  // When user inputs a valid color, it sets the style's background color
  return (
    <div>
      <input
        type="text"
        placeholder="Enter a color name"
        value={color}
        onChange={(e) => setColor(e.target.value)}
      />
      <div
        style={{
          width: "100px",
          height: "100px",
          backgroundColor: isValidColor(color) ? color : "white",
          marginTop: "10px",
          border: "1px solid black",
        }}
      ></div>
    </div>
  );
};

export default ColorChanger;

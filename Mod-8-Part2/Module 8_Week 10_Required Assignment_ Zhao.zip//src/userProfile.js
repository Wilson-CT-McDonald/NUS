import React, { useState, useEffect } from "react";

const UserProfile = () => {
  // To store user data
  const [userData, setUserData] = useState(null);
  // To track loading status
  const [loading, setLoading] = useState(true);

  // Use fetch() to make API request
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/users/1"
        );
        const data = await response.json();
        setUserData(data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // if data is fetching, loading state is true, display loading.
  // once data is fetched, loading state is set to false, displaying user data.
  // if error occurs, error message will be logged to console.
  if (loading) {
    return <p>Loading...</p>;
  }

  // Once data is fetched, display user's name, email and address
  return (
    <div>
      <h2>Q3: User Profile</h2>
      {userData && (
        <div>
          <p>
            <strong>Name:</strong> {userData.name}
          </p>
          <p>
            <strong>Email:</strong> {userData.email}
          </p>
          <p>
            <strong>Address:</strong> {userData.address.street},{" "}
            {userData.address.suite}, {userData.address.city},{" "}
            {userData.address.zipcode}
          </p>
        </div>
      )}
    </div>
  );
};

export default UserProfile;

import "./styles.css";
import ToggleMessage from "./ToggleMessage";
import ColorChanger from "./ColorChanger";
import UserProfile from "./userProfile";

export default function App() {
  return (
    <div className="App">
      <h1>Wilson's Mod8 Part 2 Assignment</h1>
      <h2>Q1: Toggle Message</h2>
      <ToggleMessage />
      <p></p>
      <h2>Q2: Color Changer</h2>
      <ColorChanger />
      <p></p>
      {/* <h2>Q3 User Profile</h2> */}
      <UserProfile />
    </div>
  );
}
